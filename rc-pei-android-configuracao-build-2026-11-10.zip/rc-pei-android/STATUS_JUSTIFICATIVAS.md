# Justificativas recebidas por data — implementação parcial

Consulta autenticada e somente leitura com seleção de `created_at` e limite de 100 linhas. Contagem por dia UTC; não retorna nome de responsável, vínculo, motivo, aluno nem anexos. O banco aplica RLS. A interface não permite registrar justificativas nem filtrar por turma ou aluno. Como o esquema não inclui um campo de estado "recebida/não recebida", não se deve inferir o status apenas dessa contagem. Necessária validação com usuário real, fuso horário da escola e dados representativos. Não houve alteração no Supabase, Sites ou produção.

**Publicação:** Android SDK e assinatura de produção não disponíveis neste ambiente; APK/AAB e Google Play não concluídos. Outras funcionalidades ainda não implementadas.
