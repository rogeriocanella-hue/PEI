# Integração de diretórios (2026-11-05)

- Tela Horários: consulta autenticada e somente leitura de até 100 turmas.
- Tela Busca Ativa: consulta autenticada e somente leitura de até 100 nomes de alunos, sem RA, telefones ou datas de nascimento.
- Validação de caminhos permitidos e bloqueio de URLs arbitrárias.
- Restrições de dados são aplicadas no cliente, mas **a segurança efetiva depende das políticas RLS do Supabase**.
- Não foram inseridos, alterados ou excluídos dados no banco; Sites não foi acessado.
- Não foi realizado teste em aparelho nem autenticação real; as consultas podem retornar lista vazia.
- A implementação de todas as funcionalidades, a compilação AAB e a publicação permanecem pendentes.
