# RC PEI Android — catálogo nativo de módulos (pré-integração)

Projeto Android Studio Java/Gradle Kotlin DSL. `applicationId`: `br.com.rcpei.app` (provisório; confirmar titularidade antes de publicar).

## Entregue nesta revisão
- Navegação nativa para 18 áreas funcionais, com identidade preta e dourada.
- Descrições dos fluxos previstos em cada área.
- Indicadores explícitos de integração pendente, evitando falsa impressão de sistema operacional.
- Nenhuma conexão com o Sites, dados de estudantes, credenciais ou backend de produção.
- `allowBackup=false`, tráfego HTTP não criptografado desativado.

## Ainda não integrado
- Código atualizado do RC PEI Sites (não acessível pelo repositório GitHub antigo).
- Banco independente Supabase (projeto encontrado INACTIVE), tabelas, políticas RLS, autenticação e armazenamento.
- API independente, sincronização incremental, modo offline seguro, LGPD, testes de autorização por perfil.
- Funcionalidade efetiva de cada módulo (o catálogo não equivale a módulos implementados).
- Testes instrumentados, APK/AAB assinado, distribuição Play Store.

## Compilação
Abra a pasta `rc-pei-android` no Android Studio, com Android SDK 35 e JDK 17, sincronize o Gradle e execute Build > Build APK(s). Este ambiente não compilou nem validou um APK/AAB.

## Regra de segurança
O site `horario-pei-canella.rogerio-canella.chatgpt.site` é somente referência e não pode ser modificado, utilizado como backend de escrita ou receber migração automática. Não armazenar dados reais no app antes de habilitar autenticação e autorização no servidor.

## Pipeline de build
Incluído workflow GitHub Actions para compilar APK debug e AAB não assinado. Consulte `PLAY_STORE_CHECKLIST.md`. Não foi executado nem publicado neste ambiente.
