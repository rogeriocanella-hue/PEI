package br.com.rcpei.app;

/** Counts attendance rows without retaining student identifiers. */
public final class AttendanceSummary {
    private int present, absent, justified, unknown;
    public void add(String status) {
        if ("Presente".equals(status)) present++;
        else if ("Falta".equals(status)) absent++;
        else if ("Justificada".equals(status)) justified++;
        else unknown++;
    }
    public int total() { return present + absent + justified + unknown; }
    public int present() { return present; }
    public int absent() { return absent; }
    public int justified() { return justified; }
    public int unknown() { return unknown; }
    public String label() {
        return "Últimos " + total() + " registros autorizados: " + present
             + " presenças, " + absent + " faltas, " + justified
             + " justificadas" + (unknown == 0 ? "" : ", " + unknown + " não reconhecidos")
             + ". Amostra limitada a 100 registros; não representa frequência geral.";
    }
}
