package br.com.rcpei.app;


/** Independent Supabase project. Never routes to the Sites application. */
public final class SupabaseContract {
    private SupabaseContract() {}
    public static final String PROJECT_URL = "https://tgrlbvtbiffqdnecbvxs.supabase.co";
    // Only approved, minimized, bounded read queries are available to the Android client.
    // Never expose select=* for students, attendance, justifications or user profiles.
    public static String readPath(String table) {
        return safeDirectoryPath(table);
    }
    public static String safeDirectoryPath(String table) {
        if ("school_classes".equals(table)) return "/rest/v1/school_classes?select=name,stage,school_year&order=name.asc&limit=100";
        if ("attendance".equals(table)) return "/rest/v1/attendance?select=attendance_date,status&order=attendance_date.desc&limit=100";
        if ("students".equals(table)) return "/rest/v1/students?select=name,enrollment_status&order=name.asc&limit=100";
        throw new IllegalArgumentException("Diretório não autorizado");
    }
    /** Exact ISO date only. Never accept arbitrary PostgREST query fragments. */
    public static String attendanceOnDate(String date) {
        if (date == null || !date.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))
            throw new IllegalArgumentException("Data inválida");
        try {
            if (!java.time.LocalDate.parse(date).toString().equals(date))
                throw new IllegalArgumentException("Data inválida");
        } catch (java.time.format.DateTimeParseException ex) {
            throw new IllegalArgumentException("Data inválida");
        }
        return "/rest/v1/attendance?select=attendance_date,status&attendance_date=eq." + date + "&limit=100";
    }
    /** Counts justifications received on the selected day. Does not fetch family details. */
    public static String justificationsReceivedOnDate(String date) {
        // Reuse strict calendar validation from the attendance contract.
        attendanceOnDate(date);
        return "/rest/v1/absence_justifications?select=created_at&created_at=gte." + date
             + "T00:00:00&created_at=lt." + java.time.LocalDate.parse(date).plusDays(1)
             + "T00:00:00&limit=100";
    }
    public static boolean isAllowedReadPath(String path) {
        if (path == null) return false;
        final String prefix="/rest/v1/attendance?select=attendance_date,status&attendance_date=eq.";
        if (path.startsWith(prefix)) {
            String date=path.substring(prefix.length());
            if (!date.endsWith("&limit=100")) return false;
            date=date.substring(0,date.length()-"&limit=100".length());
            try { return attendanceOnDate(date).equals(path); }
            catch (IllegalArgumentException ex) { return false; }
        }
        final String justificationPrefix="/rest/v1/absence_justifications?select=created_at&created_at=gte.";
        if (path.startsWith(justificationPrefix)) {
            String tail=path.substring(justificationPrefix.length());
            if (tail.length() < 10) return false;
            String date=tail.substring(0,10);
            try { return justificationsReceivedOnDate(date).equals(path); }
            catch (RuntimeException ex) { return false; }
        }
        if (path.equals(safeDirectoryPath("school_classes")) || path.equals(safeDirectoryPath("students")) || path.equals(safeDirectoryPath("attendance"))) return true;
        return false;
    }
    public static boolean hasUsableSession(String accessToken, String publishableKey) {
        return accessToken != null && !accessToken.isBlank()
            && publishableKey != null && !publishableKey.isBlank();
    }
    public static boolean canEditStudentData(String role) {
        return "admin".equals(role) || "gestor".equals(role);
    }
}
