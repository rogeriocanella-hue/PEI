package br.com.rcpei.app;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Pure calculations. No student data is persisted or transmitted. */
public final class AttendanceRules {
    private AttendanceRules() {}
    public static final class Summary {
        public final String id, name, className;
        public final int present, absent, justified;
        public Summary(String id, String name, String className, int present, int absent, int justified) {
            if (present < 0 || absent < 0 || justified < 0) throw new IllegalArgumentException("negative count");
            this.id=id; this.name=name; this.className=className;
            this.present=present; this.absent=absent; this.justified=justified;
        }
        public double rate() {
            int total=present+absent+justified;
            return total==0 ? Double.NaN : 100.0*present/total;
        }
    }
    public static List<Summary> rankStudents(List<Summary> records) {
        List<Summary> ranked=new ArrayList<>(records);
        ranked.sort(Comparator.comparingDouble((Summary s)->Double.isNaN(s.rate()) ? -1 : s.rate())
                .reversed().thenComparing(s->s.name, String.CASE_INSENSITIVE_ORDER).thenComparing(s->s.id));
        return Collections.unmodifiableList(ranked);
    }
    public static final class Justification {
        public final String id, studentId, className;
        public final LocalDate date;
        public final boolean received;
        public Justification(String id,String studentId,String className,LocalDate date,boolean received){
            this.id=id;this.studentId=studentId;this.className=className;this.date=date;this.received=received;
        }
    }
    public static List<Justification> filterJustifications(List<Justification> entries, LocalDate from, LocalDate to,
                                                            String className, String studentId, Boolean received) {
        if (from!=null && to!=null && from.isAfter(to)) throw new IllegalArgumentException("invalid date range");
        List<Justification> out=new ArrayList<>();
        for (Justification j:entries) {
            if(from!=null && j.date.isBefore(from))continue;
            if(to!=null && j.date.isAfter(to))continue;
            if(className!=null && !className.isEmpty() && !className.equals(j.className))continue;
            if(studentId!=null && !studentId.isEmpty() && !studentId.equals(j.studentId))continue;
            if(received!=null && received!=j.received)continue;
            out.add(j);
        }
        out.sort(Comparator.comparing((Justification j)->j.date).reversed().thenComparing(j->j.id));
        return Collections.unmodifiableList(out);
    }
}
