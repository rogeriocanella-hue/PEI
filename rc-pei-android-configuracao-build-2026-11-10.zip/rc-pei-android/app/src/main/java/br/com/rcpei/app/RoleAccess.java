package br.com.rcpei.app;

/** Client-side UX gating only; all access must also be enforced by Supabase RLS. */
public final class RoleAccess {
  private RoleAccess() {}
  public static boolean knownRole(String role) {
    return "admin".equals(role)||"gestor".equals(role)||"professor".equals(role)||"aoe".equals(role)||"supervisor".equals(role);
  }
  public static boolean mayShowModule(String role, int moduleIndex) {
    if(!knownRole(role)||moduleIndex<0||moduleIndex>17)return false;
    if("admin".equals(role)||"gestor".equals(role))return true;
    if("supervisor".equals(role))return moduleIndex!=17;
    if("aoe".equals(role))return moduleIndex==1||moduleIndex==4||moduleIndex==5||moduleIndex==7||moduleIndex==8||moduleIndex==9;
    return moduleIndex!=14&&moduleIndex!=17;
  }
}
