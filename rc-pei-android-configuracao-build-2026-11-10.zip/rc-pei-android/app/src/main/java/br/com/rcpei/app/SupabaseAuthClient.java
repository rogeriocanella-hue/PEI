package br.com.rcpei.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Password login adapter. Never persists passwords or tokens; caller must use a worker thread. */
public final class SupabaseAuthClient {
    private final String publishableKey;
    public SupabaseAuthClient(String key) {
        if (key == null || !key.startsWith("sb_publishable_"))
            throw new IllegalArgumentException("Configure uma chave pública Supabase válida");
        this.publishableKey = key;
    }
    public String signIn(String email, String password) throws Exception {
        if (!AuthValidation.validEmail(email) || !AuthValidation.validPassword(password))
            throw new IllegalArgumentException("Informe e-mail e senha válidos");
        URL url = new URL(SupabaseContract.PROJECT_URL + "/auth/v1/token?grant_type=password");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        try {
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(15000);
            conn.setRequestProperty("apikey", publishableKey);
            conn.setRequestProperty("Content-Type", "application/json");
            String body = "{\"email\":\"" + AuthValidation.escapeJson(email.trim()) +
                "\",\"password\":\"" + AuthValidation.escapeJson(password) + "\"}";
            try (OutputStream out = conn.getOutputStream()) {out.write(body.getBytes(StandardCharsets.UTF_8));}
            int status = conn.getResponseCode();
            if (status < 200 || status >= 300) throw new IllegalStateException("Login recusado (HTTP " + status + ")");
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buf = new byte[2048]; int n;
                while ((n = in.read(buf)) != -1) {
                    if (out.size() + n > 65536) throw new IllegalStateException("Resposta de login excedeu o limite");
                    out.write(buf, 0, n);
                }
                return out.toString(StandardCharsets.UTF_8);
            }
        } finally { conn.disconnect(); }
    }
}
