package br.com.rcpei.app;
/** Rules independent of network and production data. */
public final class SchoolRules {
 private SchoolRules() {}
 public static boolean substitutionAllowed(int assigned, int substitutions, int requested, boolean available, boolean courseOrAtpca, boolean excludedRole) {
  return assigned>=0 && substitutions>=0 && requested>0 && available && !courseOrAtpca && !excludedRole && (long)assigned+substitutions+requested<=32;
 }
 public static boolean tutorAlert(int consecutive, int intermittent) { return consecutive>=3 || intermittent>=3; }
 public static boolean below80(double attendance) { return !Double.isNaN(attendance) && attendance>=0 && attendance<80; }
 public static boolean maySendAbsenceMessage(boolean alreadySentToday) { return !alreadySentToday; }
 public static boolean mayView(boolean authorized) { return authorized; }
}
