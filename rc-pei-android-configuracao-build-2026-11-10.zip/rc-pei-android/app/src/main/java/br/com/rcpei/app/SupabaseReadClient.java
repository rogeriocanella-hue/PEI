package br.com.rcpei.app;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Authenticated read-only HTTP adapter. Must run on a background thread.
 *  Server-side RLS remains the authority; this class does not grant permissions.
 */
public final class SupabaseReadClient {
    private final String publishableKey;
    private final String accessToken;
    public SupabaseReadClient(String publishableKey, String accessToken) {
        if (!SupabaseContract.hasUsableSession(accessToken, publishableKey))
            throw new IllegalArgumentException("Sessão autenticada e chave pública necessárias");
        this.publishableKey = publishableKey;
        this.accessToken = accessToken;
    }
    public String readTable(String table) throws Exception {
        return readPath(SupabaseContract.readPath(table));
    }
    public String readPath(String path) throws Exception {
        if (!SupabaseContract.isAllowedReadPath(path)) throw new IllegalArgumentException("Consulta não autorizada");
        URL url = new URL(SupabaseContract.PROJECT_URL + path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        try {
            conn.setRequestMethod("GET");
            conn.setRequestProperty("apikey", publishableKey);
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(15000);
            int status = conn.getResponseCode();
            if (status < 200 || status >= 300)
                throw new IllegalStateException("Consulta recusada pelo servidor (HTTP " + status + ")");
            try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] chunk = new byte[4096];
                int read;
                while ((read = in.read(chunk)) != -1) {
                    if (out.size() + read > 2_000_000) throw new IllegalStateException("Resposta muito grande");
                    out.write(chunk, 0, read);
                }
                return out.toString(StandardCharsets.UTF_8);
            }
        } finally { conn.disconnect(); }
    }
}
