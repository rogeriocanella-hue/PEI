package br.com.rcpei.app;
public final class AuthValidation {
    private AuthValidation() {}
    public static boolean validEmail(String email) {
        return email != null && email.length() <= 254 && email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    }
    public static boolean validPassword(String password) {
        return password != null && !password.isEmpty() && password.length() <= 4096;
    }
    public static String escapeJson(String input) {
        if (input == null) throw new IllegalArgumentException("Valor ausente");
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default: if (c < 32) b.append(String.format("\\u%04x", (int)c)); else b.append(c);
            }
        }
        return b.toString();
    }
}
