package br.com.rcpei.app;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/** Fetches the authenticated user's own profile. Server RLS is authoritative. */
public final class SessionProfileClient {
  private final String publicKey;
  private final String token;
  public SessionProfileClient(String publicKey, String token) {
    if (!SupabaseContract.hasUsableSession(token, publicKey)) throw new IllegalArgumentException("Sessão ausente");
    this.publicKey=publicKey; this.token=token;
  }
  private String get(String path) throws Exception {
    HttpURLConnection conn=(HttpURLConnection)new URL(SupabaseContract.PROJECT_URL+path).openConnection();
    try {
      conn.setConnectTimeout(10000);conn.setReadTimeout(15000);
      conn.setRequestProperty("apikey",publicKey);
      conn.setRequestProperty("Authorization","Bearer "+token);
      conn.setRequestProperty("Accept","application/json");
      int status=conn.getResponseCode();
      if(status<200||status>=300) throw new IllegalStateException("Consulta recusada HTTP "+status);
      try(InputStream in=conn.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()) {
        byte[] buffer=new byte[2048];int n;
        while((n=in.read(buffer))!=-1){if(out.size()+n>65536)throw new IllegalStateException("Resposta excede limite");out.write(buffer,0,n);}
        return out.toString(StandardCharsets.UTF_8);
      }
    }finally{conn.disconnect();}
  }
  public String getOwnUser() throws Exception {return get("/auth/v1/user");}
  public String getOwnProfile(String userId) throws Exception {UUID.fromString(userId);return get(ProfileContract.ownProfilePath(userId));}
}
