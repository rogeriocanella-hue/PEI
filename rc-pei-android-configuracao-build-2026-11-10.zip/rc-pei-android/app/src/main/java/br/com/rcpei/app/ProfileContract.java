package br.com.rcpei.app;

import java.util.UUID;

/** Profile lookup is scoped by authenticated user ID AND protected by server-side RLS. */
public final class ProfileContract {
    private ProfileContract() {}
    public static String ownProfilePath(String userId) {
        UUID id = UUID.fromString(userId);
        return "/rest/v1/user_profiles?select=user_id,school_id,display_name,role,permissions&user_id=eq."
                + id.toString() + "&limit=1";
    }
    /** Labels are display-only, never an authorization decision. */
    public static String roleLabel(String serverRole) {
        if (serverRole == null) return "Perfil não configurado";
        switch (serverRole) {
            case "admin": return "Administrador";
            case "gestor": return "Gestão escolar";
            case "professor": return "Professor";
            case "aoe": return "AOE";
            case "supervisor": return "Supervisor URE";
            default: return "Perfil não configurado";
        }
    }
}
