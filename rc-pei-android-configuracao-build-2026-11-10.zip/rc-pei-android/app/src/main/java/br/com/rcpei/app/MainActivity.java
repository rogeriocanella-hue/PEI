package br.com.rcpei.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.CheckBox;
import android.text.InputType;
import org.json.JSONObject;
import org.json.JSONArray;

/** Navigation scaffold only. Does not authenticate or fetch/write student data. */
public final class MainActivity extends Activity {
 private static final int GOLD=Color.rgb(212,175,55), DARK=Color.rgb(13,13,13);
 private String sessionToken;
 private String currentRole;
 private String currentDisplayName;
 private static final String[][] MODULES={
  {"Horários","Matrizes, turmas, docentes, regras PEI, geração e relatórios"},
  {"Busca Ativa e Frequência","Chamada, justificativas, notificações e rankings"},
  {"Tutoria","Atendimentos coletivos, individuais e cronograma"},
  {"Ausências de Professores","Substituições e limite de 32 aulas semanais"},
  {"Ocorrências de Alunos","Registro, encaminhamento, devolutiva e histórico"},
  {"Agenda","Agenda escolar e individual, eventos e alertas"},
  {"Alimentação","Cardápio, fotos e relatórios"},
  {"Transporte","Ocorrências, evidências e acompanhamento"},
  {"Limpeza","Vistorias, fotos e status"},
  {"Manutenção","Chamados, prioridades e acompanhamento"},
  {"Boas Práticas","Portfólio e validação pedagógica"},
  {"Torneio Cel","Pontuação e classificação por turma"},
  {"AEE","Alunos, AJ, planos e ensino colaborativo"},
  {"DOCS","Guias, PDI, AR/AL e plano de ação"},
  {"Financeiro","Despesas, notas, anexos e PDF único"},
  {"Regimento e Calendário","Documentos institucionais e calendário"},
  {"Relatório de Alunos","Boletins, conceitos, frequência e evolução"},
  {"Acessos e Permissões","Perfis, autorização e auditoria"}
 };
 @Override public void onCreate(Bundle state){super.onCreate(state); showHome();}
 private TextView text(String value,int size,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(Color.WHITE);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
 private LinearLayout page(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,30,24,30);l.setBackgroundColor(DARK);return l;}
 private void display(LinearLayout l){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.addView(l);setContentView(s);}
 private void showHome(){LinearLayout root=page();TextView title=text("RC PEI",30,true);title.setTextColor(GOLD);root.addView(title);TextView subtitle=text(currentDisplayName==null?"Sistema de Gestão Educacional • Android":("Bem-vindo, "+currentDisplayName+" • "+ProfileContract.roleLabel(currentRole)),14,false);subtitle.setPadding(0,8,0,20);root.addView(subtitle);
  TextView warning=text("AMBIENTE DE DESENVOLVIMENTO: navegação limitada ao perfil autenticado. Ainda não há operações com dados escolares. As regras de acesso definitivas dependem do servidor.",14,false);warning.setPadding(14,14,14,18);warning.setBackgroundColor(Color.rgb(48,37,18));root.addView(warning);
  Button login=new Button(this);login.setText(sessionToken==null?"Entrar no Supabase (ambiente de testes)":"Sessão ativa • Sair");login.setOnClickListener(v->{if(sessionToken!=null){sessionToken=null;currentRole=null;currentDisplayName=null;showHome();}else showLogin();});root.addView(login);
  for(int i=0;i<MODULES.length;i++){if(currentRole==null || !RoleAccess.mayShowModule(currentRole,i))continue;final int idx=i;Button b=new Button(this);b.setAllCaps(false);b.setText(MODULES[i][0]+"  ›");b.setTextColor(GOLD);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(36,36,36)));b.setOnClickListener(v->showModule(idx));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=8;root.addView(b,p);}display(root);
 }
 private void showLogin(){
  LinearLayout root=page(); Button back=new Button(this);back.setText("‹ Voltar");back.setOnClickListener(v->showHome());root.addView(back);
  TextView title=text("Login Supabase • testes",24,true);title.setTextColor(GOLD);root.addView(title);
  root.addView(text("Somente usuários previamente cadastrados no Supabase. A senha não é armazenada neste aparelho.",14,false));
  EditText email=new EditText(this);email.setHint("E-mail");email.setSingleLine(true);email.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);root.addView(email);
  EditText password=new EditText(this);password.setHint("Senha");password.setSingleLine(true);password.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);root.addView(password);
  TextView status=text("",14,false);root.addView(status);
  Button submit=new Button(this);submit.setText("Entrar");root.addView(submit);
  submit.setOnClickListener(v->{
    String key=BuildConfig.SUPABASE_PUBLISHABLE_KEY;
    String mail=email.getText().toString().trim();String secret=password.getText().toString();
    if(key.isEmpty()){status.setText("Login desabilitado: configure a chave pública na compilação.");return;}
    if(!AuthValidation.validEmail(mail)||!AuthValidation.validPassword(secret)){status.setText("Informe e-mail e senha válidos.");return;}
    submit.setEnabled(false);status.setText("Validando sessão...");
    new Thread(()->{
      try {
        String response=new SupabaseAuthClient(key).signIn(mail,secret);
        JSONObject json=new JSONObject(response);String token=json.optString("access_token", "");
        if(token.isEmpty())throw new IllegalStateException("Servidor não retornou sessão");
        SessionProfileClient profileClient=new SessionProfileClient(key,token);
        JSONObject user=new JSONObject(profileClient.getOwnUser());
        String userId=user.optString("id","");
        java.util.UUID.fromString(userId);
        org.json.JSONArray profiles=new org.json.JSONArray(profileClient.getOwnProfile(userId));
        if(profiles.length()!=1)throw new IllegalStateException("Perfil escolar não cadastrado");
        JSONObject profile=profiles.getJSONObject(0);
        String role=profile.optString("role","");
        if(!RoleAccess.knownRole(role)||profile.optString("school_id","").isEmpty())
          throw new IllegalStateException("Perfil escolar inválido");
        String name=profile.optString("display_name","").trim();
        runOnUiThread(()->{sessionToken=token;currentRole=role;currentDisplayName=name.isEmpty()?"Usuário":name;password.setText("");showHome();});
      }catch(Exception e){runOnUiThread(()->{password.setText("");status.setText("Não foi possível entrar ou localizar um perfil escolar autorizado. Confira a conta e a conexão.");submit.setEnabled(true);});}
    }).start();
  });
  display(root);
 }
 private EditText numeric(LinearLayout root,String label){
  TextView t=text(label,15,false);t.setPadding(0,12,0,4);root.addView(t);
  EditText e=new EditText(this);e.setSingleLine(true);e.setInputType(InputType.TYPE_CLASS_NUMBER);e.setTextColor(Color.WHITE);e.setHintTextColor(Color.LTGRAY);root.addView(e);return e;
 }
 private Integer parse(EditText e){try{return Integer.valueOf(e.getText().toString().trim());}catch(NumberFormatException ex){return null;}}
 private void showSubstitutionCalculator(LinearLayout root){
  TextView h=text("Simulador de substituição (sem salvar dados)",18,true);h.setTextColor(GOLD);h.setPadding(0,22,0,0);root.addView(h);
  EditText regular=numeric(root,"Aulas regulares na semana");
  EditText done=numeric(root,"Substituições já realizadas na semana");
  EditText requested=numeric(root,"Aulas solicitadas para substituição");
  CheckBox available=new CheckBox(this);available.setText("Professor disponível");available.setTextColor(Color.WHITE);root.addView(available);
  CheckBox conflict=new CheckBox(this);conflict.setText("Conflito com curso ou ATPCA");conflict.setTextColor(Color.WHITE);root.addView(conflict);
  CheckBox excluded=new CheckBox(this);excluded.setText("Função excluída das substituições");excluded.setTextColor(Color.WHITE);root.addView(excluded);
  TextView result=text("Informe as quantidades para avaliar.",16,false);root.addView(result);
  Button calc=new Button(this);calc.setText("Verificar substituição");root.addView(calc);
  calc.setOnClickListener(v->{Integer a=parse(regular),b=parse(done),c=parse(requested);
    if(a==null||b==null||c==null||a<0||b<0||c<=0){result.setText("Informe números válidos (aulas solicitadas maior que zero).");return;}
    boolean ok=SchoolRules.mayAssignSubstitution(a,b,c,available.isChecked(),conflict.isChecked(),excluded.isChecked());
    result.setText(ok?"APTO: a substituição respeita as condições informadas.":"NÃO APTO: confira limite de 32 aulas, disponibilidade, cursos/ATPCA e função.");
  });
 }
 private void showAttendanceCalculator(LinearLayout root){
  TextView h=text("Simulador de frequência (sem salvar dados)",18,true);h.setTextColor(GOLD);h.setPadding(0,22,0,0);root.addView(h);
  EditText total=numeric(root,"Total de aulas previstas");
  EditText present=numeric(root,"Total de presenças");
  TextView result=text("Informe as quantidades para calcular.",16,false);root.addView(result);
  Button calc=new Button(this);calc.setText("Calcular frequência");root.addView(calc);
  calc.setOnClickListener(v->{Integer a=parse(total),b=parse(present);
    if(a==null||b==null||a<=0||b<0||b>a){result.setText("Dados inválidos: total deve ser positivo e presenças entre 0 e total.");return;}
    double pct=100.0*b/a;
    result.setText(String.format(java.util.Locale.forLanguageTag("pt-BR"),"Frequência: %.2f%%. %s",pct,
      SchoolRules.needsAttendanceIntervention(pct)?"Abaixo de 80%: requer acompanhamento.":"Não está abaixo de 80%."));
  });
 }
 private void showReadOnlyDirectory(LinearLayout root, String table, String heading) {
  TextView label=text(heading,18,true);label.setTextColor(GOLD);root.addView(label);
  TextView result=text("Nenhuma consulta realizada.",14,false);root.addView(result);
  Button load=new Button(this);load.setText("Consultar registros autorizados");root.addView(load);
  load.setOnClickListener(v->{
   if(sessionToken==null){result.setText("Entre para consultar.");return;}
   final String token=sessionToken;
   load.setEnabled(false);result.setText("Consultando...");
   new Thread(()->{
    try {
     String raw=new SupabaseReadClient(BuildConfig.SUPABASE_PUBLISHABLE_KEY,token)
         .readPath(SupabaseContract.safeDirectoryPath(table));
     JSONArray rows=new JSONArray(raw);StringBuilder lines=new StringBuilder();
     for(int i=0;i<rows.length();i++) {
      JSONObject item=rows.getJSONObject(i);
      lines.append(item.optString("name","Sem nome"));
      if("school_classes".equals(table))lines.append(" • ").append(item.optString("stage",""));
      lines.append("\n");
     }
     String output=rows.length()==0?"Nenhum registro disponível para este perfil.":lines.toString();
     runOnUiThread(()->{if(token.equals(sessionToken))result.setText(output);load.setEnabled(true);});
    } catch(Exception ex){runOnUiThread(()->{result.setText("Consulta não disponível. Confira permissões e conexão.");load.setEnabled(true);});}
   }).start();
  });
 }
 private void showAttendanceReadOnly(LinearLayout root) {
  TextView heading=text("Resumo de frequência (somente leitura)",18,true);
  heading.setTextColor(GOLD);root.addView(heading);
  TextView output=text("Consulta não realizada.",14,false);root.addView(output);
  Button load=new Button(this);load.setText("Consultar até 100 registros autorizados");root.addView(load);
  EditText dateInput=new EditText(this);
  dateInput.setSingleLine(true);dateInput.setHint("AAAA-MM-DD");
  dateInput.setText(java.time.LocalDate.now().toString());root.addView(dateInput);
  load.setOnClickListener(v->{
   final String date=dateInput.getText().toString().trim();
   final String path;
   try { path=SupabaseContract.attendanceOnDate(date); }
   catch(IllegalArgumentException ex){output.setText("Informe uma data válida (AAAA-MM-DD).");return;}
   if(sessionToken==null){output.setText("Entre com seu perfil escolar.");return;}
   final String token=sessionToken;load.setEnabled(false);output.setText("Consultando...");
   new Thread(()->{
    try {
     String raw=new SupabaseReadClient(BuildConfig.SUPABASE_PUBLISHABLE_KEY,token)
        .readPath(path);
     JSONArray rows=new JSONArray(raw);
     AttendanceSummary summary=new AttendanceSummary();
     for(int i=0;i<rows.length();i++) summary.add(rows.getJSONObject(i).optString("status",""));
     String message="Data: " + date + ". " + summary.label();
     runOnUiThread(()->{if(token.equals(sessionToken))output.setText(message);load.setEnabled(true);});
    } catch(Exception e){runOnUiThread(()->{output.setText("Consulta indisponível. Verifique a conexão e as permissões.");load.setEnabled(true);});}
   }).start();
  });
 }
 private void showJustificationsReadOnly(LinearLayout root) {
  TextView heading=text("Justificativas recebidas por dia (somente leitura)",18,true);
  heading.setTextColor(GOLD);root.addView(heading);
  EditText dateInput=new EditText(this);dateInput.setSingleLine(true);
  dateInput.setHint("AAAA-MM-DD");dateInput.setText(java.time.LocalDate.now().toString());root.addView(dateInput);
  TextView output=text("Consulta não realizada.",14,false);root.addView(output);
  Button load=new Button(this);load.setText("Contar justificativas recebidas");root.addView(load);
  load.setOnClickListener(v->{
   final String date=dateInput.getText().toString().trim();final String path;
   try {path=SupabaseContract.justificationsReceivedOnDate(date);}
   catch(RuntimeException ex){output.setText("Informe uma data válida (AAAA-MM-DD).");return;}
   if(sessionToken==null){output.setText("Entre com seu perfil escolar.");return;}
   final String token=sessionToken;load.setEnabled(false);output.setText("Consultando...");
   new Thread(()->{
    try {
     String raw=new SupabaseReadClient(BuildConfig.SUPABASE_PUBLISHABLE_KEY,token).readPath(path);
     JSONArray rows=new JSONArray(raw);int count=rows.length();
     String message="Justificativas recebidas em " + date + ": " + count
       + (count==100 ? " ou mais (limite da consulta)." : ".")
       + " Sem dados pessoais. Data considerada em UTC.";
     runOnUiThread(()->{if(token.equals(sessionToken))output.setText(message);load.setEnabled(true);});
    } catch(Exception ex){runOnUiThread(()->{output.setText("Consulta indisponível. Confira acesso e conexão.");load.setEnabled(true);});}
   }).start();
  });
 }
 private void showModule(int idx){if(currentRole==null || !RoleAccess.mayShowModule(currentRole,idx)){showHome();return;}LinearLayout root=page();Button back=new Button(this);back.setText("‹ Voltar aos módulos");back.setAllCaps(false);back.setOnClickListener(v->showHome());root.addView(back);TextView title=text(MODULES[idx][0],25,true);title.setTextColor(GOLD);title.setPadding(0,24,0,14);root.addView(title);root.addView(text(MODULES[idx][1],17,false));TextView state=text("Operações com dados reais indisponíveis até autenticação e API independente serem validadas. Os simuladores abaixo não armazenam informações.",15,false);state.setPadding(0,28,0,0);root.addView(state);
  if(idx==3)showSubstitutionCalculator(root);
  if(idx==1 && sessionToken!=null) showReadOnlyDirectory(root,"students","Alunos (somente consulta)");
  if(idx==0 && sessionToken!=null) showReadOnlyDirectory(root,"school_classes","Turmas (somente consulta)");
  if(idx==1){showAttendanceCalculator(root);if(sessionToken!=null){showAttendanceReadOnly(root);showJustificationsReadOnly(root);}}
  display(root);}
}
