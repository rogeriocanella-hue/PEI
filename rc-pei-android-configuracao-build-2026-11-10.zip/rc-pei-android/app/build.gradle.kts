plugins { id("com.android.application") }
android {
    namespace = "br.com.rcpei.app"
    compileSdk = 35
    buildFeatures { buildConfig = true }
    defaultConfig {
        applicationId = "br.com.rcpei.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0-dev"
        val publicKey = providers.environmentVariable("RCPEI_SUPABASE_PUBLISHABLE_KEY").orElse("").get()
        require(!publicKey.contains("sb_secret_") && !publicKey.contains("service_role")) {
            "Never embed Supabase secret/service-role credentials in an Android app."
        }
        buildConfigField("String", "SUPABASE_PUBLISHABLE_KEY", "\"${publicKey}\"")
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
