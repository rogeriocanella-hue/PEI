# Validação de 05/11/2026

- Corrigida inconsistência entre o teste legado e o novo contrato de consulta limitada de frequência.
- Todos os grupos de testes locais passaram após correção.
- Conferido esquema real das tabelas `attendance` e `absence_justifications` no Supabase; nenhuma escrita no banco.
- Não houve compilação com Android SDK, teste em dispositivo, autenticação com conta real, geração de AAB ou publicação.
- Sites de produção não alterado.
