# Frequência por data (desenvolvimento)
- Consulta somente leitura de frequência por data ISO válida, limitada a 100 linhas.
- Não inclui identificadores pessoais nem modifica dados.
- O resumo é amostral, não substitui relatório integral.
- A interpretação de status depende de valores reais e deve ser validada antes do uso operacional.
- Testes locais Java, sem compilação Android ou teste em conta real.
- Sites original não foi acessado ou alterado.
