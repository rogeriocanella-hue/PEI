# Status da aplicação RC PEI Android

Implementado: projeto Android inicial, catálogo de 18 módulos e regras Java isoladas para limite de substituições de 32 aulas, impedimento durante curso/ATPCA, alertas de tutoria, frequência inferior a 80%, duplicidade de mensagem e verificação simples de permissão. Treze testes dessas regras passam via `bash tests/run-tests.sh`.

Pendente: conectar as regras às telas e à base real, autenticação segura, API e banco independente, relatórios, importação, sincronização, compilação e assinatura AAB, testes em dispositivos e publicação. O código atualizado do Sites não foi recuperado. O Sites não foi modificado.

NÃO UTILIZAR COM DADOS REAIS DE ALUNOS. Não é aplicativo escolar pronto para produção.

## Atualização 05/11/2026
Adicionadas regras puras para ranking individual de frequência e filtros de justificativas por data, turma, aluno e situação recebida/não recebida. Dez verificações novas passaram, totalizando 23 verificações locais. A automação de build executará esses testes antes da compilação. Nenhuma tela, API ou banco foi integrado nesta etapa.
