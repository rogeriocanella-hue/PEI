# Etapa: consulta segura do perfil do usuário

- Adicionado contrato de consulta ao perfil do próprio usuário (`user_profiles`) com UUID validado e limite de um registro.
- Consulta usa campos explícitos; acesso deve ser protegido pela sessão autenticada e pela RLS do Supabase.
- Mapeamento de papéis do banco para rótulos visuais; `gestor` não distingue Diretor/Vice/Coordenador. Não conceder privilégios com base em rótulos.
- Não foram criadas contas, alteradas políticas, importados alunos ou modificada a versão Sites.
- Ainda falta vincular o contrato ao fluxo de login Android, validar RLS com contas de teste e aplicar permissões por módulo no servidor.
- Não há APK/AAB compilado, assinatura ou publicação na Play Store.
