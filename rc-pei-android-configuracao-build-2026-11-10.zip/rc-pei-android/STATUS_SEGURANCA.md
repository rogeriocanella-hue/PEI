# Etapa de segurança das consultas Android

- Eliminadas rotas genéricas `select=*` no adaptador de leitura Android.
- Somente dois diretórios minimizados, com limite de 100, são aceitos: turmas e alunos.
- Frequência, justificativas, perfis e outros dados não podem ser lidos por esse adaptador sem implementar endpoints restritos e testes específicos.
- As políticas RLS no Supabase permanecem a autoridade de autorização.
- Nenhuma alteração feita no Supabase ou no RC PEI Sites.
- Não foi compilado APK/AAB nem validado login real em dispositivo.
