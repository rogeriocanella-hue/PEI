# Integração de autenticação — estágio de testes

## Implementado
- Tela nativa para login por e-mail e senha no Supabase Auth (HTTPS).
- Requisição de login executada fora da thread principal.
- Token de acesso mantido **somente em memória**; logout local o descarta.
- Senha não é armazenada; campo de senha limpo após tentativa.
- Chave **pública** de API configurada na compilação pela variável `RCPEI_SUPABASE_PUBLISHABLE_KEY` (nunca use service_role).
- 45 verificações locais de regras/contrato/validação passaram.

## Ainda pendente
- Testar login real com usuário de testes e verificar perfis/RLS na API.
- Integrar sessão e autorização aos módulos e renovação de sessão.
- Integrar cadastros, frequência, justificativas e demais funcionalidades.
- Compilar APK/AAB com Android SDK, assinar e testar em dispositivos.
- Play Console, política de privacidade, requisitos de acesso e revisão Google.

**Atenção:** a tela de login é experimental. Não utilizar dados de alunos nem credenciais de produção antes da auditoria e testes de segurança. Não altera o Sites.
