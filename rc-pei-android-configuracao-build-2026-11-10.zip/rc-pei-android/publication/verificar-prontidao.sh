#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo '=== RC PEI: testes locais ==='
bash tests/run-tests.sh
echo '=== Inspeção de requisitos de publicação ==='
if command -v gradle >/dev/null 2>&1 && [ -n "${ANDROID_HOME:-}" ]; then
  echo 'Gradle e ANDROID_HOME disponíveis. A compilação Android deve ser executada separadamente.'
else
  echo 'BLOQUEIO: Gradle ou ANDROID_HOME indisponível; compilação AAB não verificada.'
fi
if [ -z "${RCPEI_SUPABASE_PUBLISHABLE_KEY:-}" ]; then
  echo 'ATENÇÃO: RCPEI_SUPABASE_PUBLISHABLE_KEY não configurada para build autenticado.'
fi
echo 'STATUS: não aprovado para publicação; consulte publication/RELATORIO_PUBLICACAO.md'

echo '=== Conferência de arquivos essenciais ==='
for required in app/src/main/AndroidManifest.xml app/build.gradle.kts .github/workflows/android-build.yml; do
  test -s "$required" || { echo "FALHA: arquivo ausente $required"; exit 1; }
done
echo 'Arquivos essenciais presentes.'
echo '=== Verificação de release ==='
if grep -q 'versionName = "0.1.0-dev"' app/build.gradle.kts; then
  echo 'BLOQUEIO: versão de desenvolvimento não publicável.'
fi
if grep -q 'bundleRelease' .github/workflows/android-build.yml && ! grep -q 'signingConfig' app/build.gradle.kts; then
  echo 'BLOQUEIO: AAB release sem assinatura configurada.'
fi
