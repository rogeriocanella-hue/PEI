# RC PEI Android — verificação de prontidão para publicação

Data da revisão: 2026-11-06

## Verificado nesta etapa
- Executado `bash tests/run-tests.sh` no pacote mais recente: todos os grupos de testes locais passaram.
- Conferido `.github/workflows/android-build.yml`: gera APK debug e AAB release **não assinado**; não executa publicação.
- Conferido `app/build.gradle.kts`: versão `0.1.0-dev`, `versionCode=1`, `targetSdk=35`; a chave pública Supabase é lida de variável de ambiente.
- Não existe APK/AAB assinado gerado ou validado nesta etapa.
- Não foi executado teste em dispositivo Android.
- Nenhum deploy, publicação ou alteração de dados do Sites foi realizado.

## Bloqueadores de lançamento
1. Obter versão-fonte completa e fiel do Sites **sem modificar produção**; o código Android atual não implementa integralmente os 18 módulos.
2. Validar contas reais, perfis e RLS, incluindo limites de acesso a dados de alunos.
3. Implementar registros operacionais, justificativas completas, sincronização e fluxos offline.
4. Compilar em Android SDK/Gradle, corrigir eventuais falhas e testar em aparelhos reais.
5. Configurar assinatura segura de release e gerar AAB assinado.
6. Confirmar titularidade da conta Play Console, política de privacidade, segurança dos dados, materiais de loja e testes exigidos.
7. Fazer publicação por conta autorizada e verificar revisão e disponibilidade.

## Garantias e limites
Os testes locais verificam regras e contratos, não demonstram funcionalidade ponta a ponta. Nenhuma aprovação de publicação deve ser inferida deles. O Sites existente não deve ser alterado.
