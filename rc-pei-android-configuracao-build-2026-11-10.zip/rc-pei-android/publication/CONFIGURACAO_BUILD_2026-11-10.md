# Configuracao de build (10/11/2026)

- Corrigida duplicacao de defaultConfig no Gradle.
- Chave publica do Supabase por variavel RCPEI_SUPABASE_PUBLISHABLE_KEY; rejeicao basica de chaves secretas.
- GitHub Actions: JDK 17, Android SDK 35, Gradle 8.9, testes, APK de teste, AAB nao assinado.
- Nenhuma alteracao no Sites, AppDeploy, GitHub ou Supabase remoto.
- Sem SDK/Gradle locais: nao foi possivel validar a compilacao Android.
- Nao publicar: modulos incompletos, perfis nao testados com contas reais, sem assinatura de release.
