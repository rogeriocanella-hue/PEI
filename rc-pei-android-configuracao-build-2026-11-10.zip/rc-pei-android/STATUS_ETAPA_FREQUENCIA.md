# Etapa: leitura limitada de frequência
- Incluída consulta HTTPS autenticada de até 100 registros de frequência, somente `attendance_date` e `status`.
- Adicionado resumo por situação, sem identificadores de alunos.
- Regras RLS do Supabase continuam sendo a autoridade.
- Testes unitários locais, sem contas reais e sem dados pessoais.
- Não representa ranking geral, relatório completo ou importação.
- Não altera Sites nem o banco Supabase.
- APK/AAB, teste em aparelho e publicação permanecem pendentes.
