import br.com.rcpei.app.AttendanceRules;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
public final class AttendanceRulesTest {
  static void ok(boolean b){if(!b)throw new AssertionError();}
  public static void main(String[] args){
    AttendanceRules.Summary a=new AttendanceRules.Summary("1","Ana","6A",9,1,0);
    AttendanceRules.Summary b=new AttendanceRules.Summary("2","Bia","6A",8,2,0);
    AttendanceRules.Summary c=new AttendanceRules.Summary("3","Caio","6B",0,0,0);
    ok(a.rate()==90.0); ok(Double.isNaN(c.rate()));
    ok(AttendanceRules.rankStudents(Arrays.asList(b,c,a)).get(0)==a);
    ok(AttendanceRules.rankStudents(Arrays.asList(b,c,a)).get(2)==c);
    LocalDate d=LocalDate.of(2026,11,4);
    AttendanceRules.Justification j1=new AttendanceRules.Justification("1","1","6A",d,true);
    AttendanceRules.Justification j2=new AttendanceRules.Justification("2","2","6B",d,false);
    List<AttendanceRules.Justification> list=Arrays.asList(j1,j2);
    ok(AttendanceRules.filterJustifications(list,d,d,"6A",null,true).size()==1);
    ok(AttendanceRules.filterJustifications(list,d,d,"6A",null,false).isEmpty());
    ok(AttendanceRules.filterJustifications(list,d,d,null,"2",null).get(0)==j2);
    ok(AttendanceRules.filterJustifications(list,d.plusDays(1),null,null,null,null).isEmpty());
    try{AttendanceRules.filterJustifications(list,d.plusDays(1),d,null,null,null);throw new AssertionError();}
    catch(IllegalArgumentException expected){}
    try{new AttendanceRules.Summary("4","D","6A",-1,0,0);throw new AssertionError();}
    catch(IllegalArgumentException expected){}
    System.out.println("10 verificações de frequência e justificativas: APROVADAS");
  }
}
