import br.com.rcpei.app.SupabaseContract;
public class SupabaseContractTest {
    static void check(boolean v, String m) { if (!v) throw new AssertionError(m); }
    public static void main(String[] args) {
        check(SupabaseContract.PROJECT_URL.startsWith("https://"), "HTTPS obrigatório");
        check(!SupabaseContract.PROJECT_URL.contains("chatgpt.site"), "Sites não pode ser backend");
        check(SupabaseContract.readPath("students").equals(SupabaseContract.safeDirectoryPath("students")), "rota estudantes minimizada");
        check(SupabaseContract.readPath("attendance").contains("select=attendance_date,status"), "frequência minimizada");
        check(SupabaseContract.isAllowedReadPath(SupabaseContract.readPath("attendance")), "rota de frequência autorizada");
        try { SupabaseContract.readPath("absence_justifications"); throw new AssertionError("justificativas sem consulta minimizada"); } catch (IllegalArgumentException expected) {}
        try { SupabaseContract.readPath("migration_backups"); throw new AssertionError("migração interna exposta"); }
        catch (IllegalArgumentException expected) {}
        try { SupabaseContract.readPath("students?select=guardian_phone"); throw new AssertionError("injeção de rota"); }
        catch (IllegalArgumentException expected) {}
        check(!SupabaseContract.hasUsableSession("", "public"), "sem sessão");
        check(!SupabaseContract.hasUsableSession("token", ""), "sem chave");
        check(SupabaseContract.hasUsableSession("token", "public"), "sessão presente");
        check(SupabaseContract.canEditStudentData("admin"), "admin edita");
        check(SupabaseContract.canEditStudentData("gestor"), "gestor edita");
        check(!SupabaseContract.canEditStudentData("professor"), "professor não edita cadastro");
        check(!SupabaseContract.canEditStudentData(null), "sem perfil não edita");
        System.out.println("14 testes do contrato Supabase: APROVADOS");
    }
}
