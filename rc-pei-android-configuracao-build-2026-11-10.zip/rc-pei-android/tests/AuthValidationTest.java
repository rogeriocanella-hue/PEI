import br.com.rcpei.app.AuthValidation;
public class AuthValidationTest {
    static void check(boolean ok) { if (!ok) throw new AssertionError(); }
    public static void main(String[] args) {
        check(AuthValidation.validEmail("teste@escola.edu.br"));
        check(!AuthValidation.validEmail("invalido"));
        check(!AuthValidation.validEmail(null));
        check(AuthValidation.validPassword("senha"));
        check(!AuthValidation.validPassword(""));
        check(AuthValidation.escapeJson("a\"b").equals("a\\\"b"));
        check(AuthValidation.escapeJson("a\\b").equals("a\\\\b"));
        check(AuthValidation.escapeJson("a\nb").equals("a\\nb"));
        System.out.println("8 testes de validação de login aprovados");
    }
}
