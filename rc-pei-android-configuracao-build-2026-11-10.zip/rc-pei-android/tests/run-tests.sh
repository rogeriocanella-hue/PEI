#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" "$DIR/app/src/main/java/br/com/rcpei/app/SchoolRules.java" "$DIR/app/src/main/java/br/com/rcpei/app/AttendanceRules.java" "$DIR/tests/SchoolRulesTest.java" "$DIR/tests/AttendanceRulesTest.java" "$DIR/app/src/main/java/br/com/rcpei/app/SupabaseContract.java" "$DIR/app/src/main/java/br/com/rcpei/app/SupabaseReadClient.java" "$DIR/tests/SupabaseContractTest.java"
java -cp "$TMP" SchoolRulesTest
java -cp "$TMP" AttendanceRulesTest

java -cp "$TMP" SupabaseContractTest
javac -d "$TMP" "$DIR/app/src/main/java/br/com/rcpei/app/AuthValidation.java" "$DIR/tests/AuthValidationTest.java"
java -cp "$TMP" AuthValidationTest
javac -cp "$TMP" -d "$TMP" "$DIR/app/src/main/java/br/com/rcpei/app/ProfileContract.java" "$DIR/tests/ProfileContractTest.java"
java -cp "$TMP" ProfileContractTest

javac -d "$TMP" "$DIR/app/src/main/java/br/com/rcpei/app/RoleAccess.java" "$DIR/tests/RoleAccessTest.java"
java -cp "$TMP" RoleAccessTest

javac -cp "$TMP" -d "$TMP" "$DIR/tests/DirectoryContractTest.java"
java -cp "$TMP" DirectoryContractTest

javac -d "$TMP" "$DIR/app/src/main/java/br/com/rcpei/app/AttendanceSummary.java" "$DIR/tests/AttendanceSummaryTest.java"
java -cp "$TMP" AttendanceSummaryTest
javac -cp "$TMP" -d "$TMP" "$DIR/tests/AttendanceContractTest.java"
java -cp "$TMP" AttendanceContractTest

javac -cp "$TMP" -d "$TMP" "$DIR/tests/AttendanceDateContractTest.java"
java -cp "$TMP" AttendanceDateContractTest

javac -cp "$TMP" -d "$TMP" "$DIR/tests/JustificationsDateContractTest.java"
java -cp "$TMP" JustificationsDateContractTest
