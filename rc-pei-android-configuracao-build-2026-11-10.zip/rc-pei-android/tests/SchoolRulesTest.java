import br.com.rcpei.app.SchoolRules;
public class SchoolRulesTest {
 static void check(boolean value) { if (!value) throw new AssertionError("Rule failed"); }
 public static void main(String[] args) {
  check(SchoolRules.substitutionAllowed(28,3,1,true,false,false));
  check(!SchoolRules.substitutionAllowed(28,3,2,true,false,false));
  check(!SchoolRules.substitutionAllowed(20,0,1,true,true,false));
  check(!SchoolRules.substitutionAllowed(20,0,1,true,false,true));
  check(!SchoolRules.substitutionAllowed(20,0,1,false,false,false));
  check(SchoolRules.tutorAlert(3,0));
  check(SchoolRules.tutorAlert(0,3));
  check(!SchoolRules.tutorAlert(2,2));
  check(SchoolRules.below80(79.99));
  check(!SchoolRules.below80(80));
  check(!SchoolRules.maySendAbsenceMessage(true));
  check(SchoolRules.maySendAbsenceMessage(false));
  check(!SchoolRules.mayView(false));
  System.out.println("13 testes de regras aprovados");
 }
}
