import br.com.rcpei.app.SupabaseContract;
public class AttendanceDateContractTest {
 public static void main(String[] args){
  String path=SupabaseContract.attendanceOnDate("2026-11-05");
  if(!SupabaseContract.isAllowedReadPath(path))throw new AssertionError("Data válida recusada");
  for(String bad:new String[]{"2026-02-30","2026-11-05&select=*","2026-1-05","", "2026-13-01"}){
   try{SupabaseContract.attendanceOnDate(bad);throw new AssertionError("Aceitou "+bad);}
   catch(IllegalArgumentException expected){}
  }
  if(SupabaseContract.isAllowedReadPath(path+"&student_id=not.is.null"))throw new AssertionError("Filtro injetado");
  System.out.println("Consulta por data: APROVADA");
 }
}
