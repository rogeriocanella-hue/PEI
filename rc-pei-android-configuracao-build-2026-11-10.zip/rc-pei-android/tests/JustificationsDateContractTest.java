import br.com.rcpei.app.SupabaseContract;
public class JustificationsDateContractTest {
 static void ok(boolean value){if(!value)throw new AssertionError("Contrato inválido");}
 public static void main(String[] args){
  String path=SupabaseContract.justificationsReceivedOnDate("2026-11-05");
  ok(SupabaseContract.isAllowedReadPath(path));
  ok(path.contains("created_at=gte.2026-11-05T00:00:00"));
  ok(path.contains("created_at=lt.2026-11-06T00:00:00"));
  ok(path.endsWith("limit=100"));
  ok(!path.contains("guardian_name")&&!path.contains("student_id"));
  ok(!SupabaseContract.isAllowedReadPath(path+"&select=*"));
  ok(!SupabaseContract.isAllowedReadPath("/rest/v1/absence_justifications?select=*"));
  try{SupabaseContract.justificationsReceivedOnDate("2026-02-30");throw new AssertionError("Data inválida aceita");}
  catch(IllegalArgumentException expected){}
  ok(SupabaseContract.isAllowedReadPath(SupabaseContract.justificationsReceivedOnDate("2026-12-31")));
  System.out.println("9 verificações de justificativas por data: APROVADAS");
 }
}
