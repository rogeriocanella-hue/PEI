import br.com.rcpei.app.SupabaseContract;
public class DirectoryContractTest {
 public static void main(String[] args) {
  for(String table : new String[]{"students","school_classes"}) {
   String path=SupabaseContract.safeDirectoryPath(table);
   if(!SupabaseContract.isAllowedReadPath(path) || !path.contains("limit=100"))throw new AssertionError(table);
  }
  for(String path : new String[]{"/rest/v1/students?select=*\u0026limit=1000","https://example.com","/rest/v1/migration_backups?select=*", "/rest/v1/students?select=*", "/rest/v1/attendance?select=*", "/rest/v1/user_profiles?select=*"})
   if(SupabaseContract.isAllowedReadPath(path))throw new AssertionError("Unsafe path");
  System.out.println("5 verificações de consulta limitada: APROVADAS");
 }
}
