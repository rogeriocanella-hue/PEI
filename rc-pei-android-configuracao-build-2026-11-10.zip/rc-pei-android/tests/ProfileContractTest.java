import br.com.rcpei.app.ProfileContract;
public final class ProfileContractTest {
    private static int count = 0;
    static void check(boolean ok) { if (!ok) throw new AssertionError("ProfileContract test " + count); count++; }
    public static void main(String[] args) {
        String id="a19d9e0f-8c1b-4b0f-9b67-1d9d3955e07f";
        String path=ProfileContract.ownProfilePath(id);
        check(path.startsWith("/rest/v1/user_profiles?"));
        check(path.contains("user_id=eq."+id));
        check(path.contains("&limit=1"));
        check(!path.contains("select=*"));
        try { ProfileContract.ownProfilePath("abc&school_id=neq.any"); throw new AssertionError("accepted injection"); }
        catch(IllegalArgumentException expected) { count++; }
        check("Administrador".equals(ProfileContract.roleLabel("admin")));
        check("Gestão escolar".equals(ProfileContract.roleLabel("gestor")));
        check("Professor".equals(ProfileContract.roleLabel("professor")));
        check("Perfil não configurado".equals(ProfileContract.roleLabel("diretor")));
        check("Perfil não configurado".equals(ProfileContract.roleLabel(null)));
        System.out.println(count+" verificações de perfis aprovadas");
    }
}
