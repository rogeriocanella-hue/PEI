import br.com.rcpei.app.RoleAccess;
public class RoleAccessTest {
 static void ok(boolean v){if(!v)throw new AssertionError();}
 public static void main(String[] args){
  ok(RoleAccess.mayShowModule("admin",17));
  ok(RoleAccess.mayShowModule("gestor",14));
  ok(!RoleAccess.mayShowModule("professor",17));
  ok(!RoleAccess.mayShowModule("professor",14));
  ok(RoleAccess.mayShowModule("professor",1));
  ok(!RoleAccess.mayShowModule("aoe",14));
  ok(RoleAccess.mayShowModule("aoe",1));
  ok(!RoleAccess.mayShowModule("supervisor",17));
  ok(!RoleAccess.mayShowModule("unknown",1));
  ok(!RoleAccess.mayShowModule("admin",18));
  System.out.println("10 verificações de navegação por perfil: APROVADAS");
 }
}
