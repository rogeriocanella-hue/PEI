import br.com.rcpei.app.SupabaseContract;
public class AttendanceContractTest {
 public static void main(String[] args) {
  String path=SupabaseContract.safeDirectoryPath("attendance");
  if(!SupabaseContract.isAllowedReadPath(path)||!path.contains("limit=100")
     ||path.contains("student_id")||path.contains("select=*"))
    throw new AssertionError("Contrato de frequência inseguro");
  if(SupabaseContract.isAllowedReadPath("/rest/v1/attendance?select=*"))
    throw new AssertionError("Consulta ampla permitida");
  System.out.println("Contrato de frequência: APROVADO");
 }
}
