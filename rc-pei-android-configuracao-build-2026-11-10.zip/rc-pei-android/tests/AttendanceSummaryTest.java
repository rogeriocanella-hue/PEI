import br.com.rcpei.app.AttendanceSummary;
public class AttendanceSummaryTest {
 public static void main(String[] args) {
  AttendanceSummary s=new AttendanceSummary();
  s.add("Presente");s.add("Falta");s.add("Justificada");s.add("Desconhecido");
  if(s.total()!=4||s.present()!=1||s.absent()!=1||s.justified()!=1||s.unknown()!=1)
   throw new AssertionError("Contagem inválida");
  if(!s.label().contains("Amostra limitada a 100")) throw new AssertionError("Falta aviso de amostragem");
  System.out.println("Resumo de frequência: APROVADO");
 }
}
