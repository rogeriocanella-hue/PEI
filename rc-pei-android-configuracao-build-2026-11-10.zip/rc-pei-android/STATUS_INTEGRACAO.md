# RC PEI Android — integração Supabase, etapa 1

## Entregue
- URL do projeto Supabase independente definida em `SupabaseContract.java`.
- Adaptador HTTP somente leitura em `SupabaseReadClient.java`, com HTTPS, timeout, limite de resposta, autenticação Bearer e chave publicável exigidas.
- Lista explícita de tabelas permitidas, sem tabelas internas de migração.
- 14 novos testes de contrato. Total executado: 37 (13 regras escolares, 10 frequência/justificativas, 14 contrato).
- Supabase foi inspecionado remotamente: projeto ACTIVE_HEALTHY; 16 tabelas com RLS ativo; políticas verificadas. Nenhum dado foi modificado.

## Limites e pendências
- O adaptador NÃO está ligado à interface do Android e NÃO houve login real, chamada autenticada, ou leitura de registros escolares.
- A chave publicável e a sessão precisam vir de autenticação legítima, sem inserir service_role em app. Não há credenciais no pacote.
- RLS do servidor precisa ser auditado por perfil antes de permitir operações de escrita.
- Ainda faltam login, atualização segura de token, gerenciamento de sessão, tratamento de dados, sincronização, todos os módulos funcionais, compilação, assinatura e testes Play Store.
- O Sites não foi consultado como API, alterado ou usado como backend.

## Rodar testes
`bash tests/run-tests.sh` com JDK 17+.

## Segurança
Não usar o app com dados reais até concluir autenticação, autorização por perfil, revisão LGPD e testes em dispositivo. Nunca publicar chaves secretas ou dados de estudantes no código.
