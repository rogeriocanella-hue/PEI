# Etapa concluída: calculadoras Android offline

- Simulador interativo de substituições: soma das aulas regulares, eventuais anteriores e solicitadas, limite de 32, disponibilidade, conflito curso/ATPCA e função excluída.
- Simulador interativo de frequência: presenças, total de aulas, percentual e aviso quando abaixo de 80%.
- Os dois simuladores usam `SchoolRules` e **não armazenam dados pessoais**.
- Os demais 16 módulos continuam demonstrativos. A Busca Ativa e o módulo de Ausências ainda **não** têm operações reais de cadastro.
- Supabase confirmado INACTIVE em 05/11/2026; sem acesso ao banco nem à versão atual do Sites.
- Sem compilação APK/AAB ou testes instrumentados no Android: SDK Android não disponível neste ambiente.
- Não é versão publicável. Sites de produção não foi modificado.
