# Preparação para Google Play — RC PEI

## Estado atual
O projeto é um catálogo navegável, **não** um sistema escolar operacional. AAB de release gerado pelo workflow é **não assinado** e **não pode ser publicado** como aplicativo pronto.

## Antes de publicar
- [ ] Obter código atualizado do RC PEI Sites, sem alterá-lo.
- [ ] Implementar os 18 módulos com testes funcionais, não apenas navegação.
- [ ] Configurar banco independente, autenticação e RLS por escola e perfil.
- [ ] Validar sincronização, dados sensíveis, modo offline e LGPD.
- [ ] Definir titularidade e ID definitivo do aplicativo.
- [ ] Gerar chave de assinatura e habilitar Play App Signing, sem versionar segredos.
- [ ] Criar política de privacidade e preencher seção Segurança dos dados.
- [ ] Preparar ícone, capturas reais, descrição e classificação indicativa.
- [ ] Testar em dispositivos Android e disponibilizar teste fechado conforme exigências da conta.
- [ ] Compilar AAB assinado, revisar permissões e enviar pelo Play Console.

## Compilação automatizada
O workflow `.github/workflows/android-build.yml` é manual ou executado em push na branch `rc-pei-android-rebuild` quando o projeto estiver no GitHub. Ele produz APK debug e AAB de release não assinado, para inspeção, sem publicar nada.

## Proteção do Sites
Nunca utilizar credenciais, API de escrita ou banco de produção do Sites sem autorização específica e revisão de segurança.
