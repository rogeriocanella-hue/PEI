# Etapa: login + perfil na interface

## Implementado
- Após login, o Android solicita `/auth/v1/user` e consulta o perfil próprio em `user_profiles`, protegido por RLS.
- Sem perfil escolar válido, a interface não abre os módulos.
- Exibe nome e papel do perfil após login; limpa sessão e perfil no botão sair.
- Oculta módulos na navegação conforme o papel (filtro visual provisório, não substitui políticas RLS).
- Testes unitários de navegação adicionados.

## Pendências críticas
- Não houve teste de autenticação real com conta de teste, nem build APK/AAB em dispositivo.
- Tokens permanecem em memória durante a sessão, sem persistência; não há refresh automático.
- Papéis Diretor/Vice/Coordenador ainda precisam de modelagem no servidor e permissões granulares.
- Módulos ainda não possuem operações reais; não migrar dados de alunos antes de validação LGPD.
- **Não publicado. Sites não alterado.**
